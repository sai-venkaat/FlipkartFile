package com.webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.common.utilites.commonFunction;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverManage {

	private static WebDriver dr = null;

	public void browserwindow() {
		try {
			switch (commonFunction.Browser) {
			case "chrome":
				WebDriverManager.chromedriver().setup();
				dr = new ChromeDriver();
				break;
			case "ie":
				WebDriverManager.iedriver().setup();
				dr = new InternetExplorerDriver();
				break;
			case "firefox":
				WebDriverManager.firefoxdriver().setup();
				dr = new FirefoxDriver();
				break;
			case "edge":
				WebDriverManager.edgedriver().setup();
				dr = new EdgeDriver();
				break;
			default:
				WebDriverManager.chromedriver().setup();
				dr = new ChromeDriver();
				break;
			}

		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static WebDriver getDr() {
		return dr;
	}

}
