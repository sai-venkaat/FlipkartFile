package browserLaunch;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import com.common.utilites.commonFunction;

import io.cucumber.java.Before;
import utilies.LoadProp;

public class BrowserLaunch {

	public static WebDriver dr;
	@Before
	public void beforeSceanrio() {
		try {
			LoadProp loadprop = new LoadProp();
			loadprop.lp1();
			if (dr == null) {
				browseropen();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void browseropen() {
		try {
			switch (commonFunction.Browser) {
			case "chrome":
				dr = new ChromeDriver();
				break;
			case "firefox":
				dr = new FirefoxDriver();
				break;
			case "ie":
				dr = new InternetExplorerDriver();
				break;
			default:
				dr = new ChromeDriver();
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
