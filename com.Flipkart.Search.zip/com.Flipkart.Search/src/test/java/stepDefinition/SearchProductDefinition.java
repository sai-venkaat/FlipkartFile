package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.common.utilites.commonFunction;
import com.webdriver.DriverManage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchProductDefinition {

	public WebDriver dr;
	

	
	@Given("User is on Flikpart home page.")
	public void user_is_on_flikpart_home_page() {
		
		DriverManage.getDr().get(commonFunction.URL);
		String URL=DriverManage.getDr().getCurrentUrl();
		
		
}

	@When("User searched with productname and extracted third place order")
	public void user_searched_with_and_extracted_third_place_order() {
		dr.findElement(By.name("q")).sendKeys("Watch", Keys.ENTER);
		dr.findElement(By.xpath("(//img[@class='_53J4C-'])[3]")).click();
	}

	@When("User navigate into home page.")
	public void user_navigate_into_home_page() {
		System.out.println("User navigate into home page.");

	}

	@Then("User access in child window and place in add to cart.")
	public void user_access_in_child_window_and_place_in_add_to_cart() {
		System.out.println("User access in child window and place in add to cart.");

	}

	@Then("Enter billing address and add item.")
	public void enter_billing_address_and_add_item() {
		System.out.println("Enter billing address and add item.");

	}

	@Then("User close current window.")
	public void user_close_current_window() {
		System.out.println("User close current window.");

	}
}
