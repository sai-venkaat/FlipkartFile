package utilies;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import com.common.utilites.commonFunction;

public class LoadProp {

	public  void lp1() {
		

		Properties prop = new Properties();
		try {
			prop.load(getClass().getResourceAsStream("/configuration.properties"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		commonFunction.URL = prop.getProperty("URL");
		commonFunction.Browser = prop.getProperty("Browser");

	}

}
