package com.common.utilites;

import io.github.bonigarcia.wdm.WebDriverManager;

public class commonFunction {

	public static String URL;

	public static String Browser;

	public void Browser(String Browser) {
		WebDriverManager.chromedriver().setup();
		this.Browser = Browser;

	}
}