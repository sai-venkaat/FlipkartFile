package com.prac;

import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Prac2 {
	
	public static WebDriver dr;

	public static void main(String[] args) throws InterruptedException {

		dr = new ChromeDriver();
		dr.manage().window().maximize();
		dr.manage().deleteAllCookies();
		dr.get("https://www.flipkart.com");
		String Parentwindow = dr.getWindowHandle();
		System.out.println("Parentwindow : " + Parentwindow + "\n");
		System.out.println(dr.getTitle());
		System.out.println(dr.getCurrentUrl());

		dr.findElement(By.name("q")).sendKeys("Watch", Keys.ENTER);

		dr.findElement(By.xpath("(//img[@class='_53J4C-'])[3]")).click();

		dr.switchTo().window(Parentwindow);

		Set<String> windows = dr.getWindowHandles();
		ArrayList<String> al = new ArrayList<>(windows);
		Thread.sleep(5000);
		WebDriver childwindow = dr.switchTo().window(al.get(1));
		childwindow.findElement(By.xpath("//*[contains(text(),'Add to cart')]")).click();
		Thread.sleep(5000);
		dr.findElement(By.xpath("//*[contains(text(),'Enter Delivery Pincode')]")).click();
		Thread.sleep(5000);

		dr.findElement(By.xpath("//input[@placeholder=\"Enter pincode\"]")).sendKeys("600094", Keys.ENTER);
		Thread.sleep(5000);
		
		
		dr.findElement(By.xpath("//*[contains(text(),'Add Item')]")).click();
		dr.close();
		
		
		
//	dr.close();
	}
}